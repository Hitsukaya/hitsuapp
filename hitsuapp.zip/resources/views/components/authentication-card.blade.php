<div class="py-12 px-2 flex flex-col sm:justify-center items-center pt-6 sm:pt-0 dark:bg-neutral-950">
    <div class="w-full mt-6 px-2 py-6 dark:bg-neutral-950">
        {{ $slot }}
    </div>
</div>
