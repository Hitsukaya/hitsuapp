<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>419 Session Expired  - <?php echo e(config('app.name', 'Laravel')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>



</head>
<body>

    <div class="flex items-center justify-center min-h-screen bg-gray-100">
        <div class="text-center">
            <h1 class="mb-4 text-4xl font-bold text-red-600">419 | Session Expired</h1>
            <p class="mb-6">It looks like your session has expired. Please refresh the page to continue.</p>
            <button onclick="location.reload()" class="px-4 py-2 text-white bg-blue-500 rounded-md hover:bg-blue-600">
                Refresh Page
            </button>
        </div>
    </div>

</body>
</html>
<?php /**PATH E:\Web Server\xampp\htdocs\hitsu-blog\hitsuapp\resources\views\errors\419.blade.php ENDPATH**/ ?>