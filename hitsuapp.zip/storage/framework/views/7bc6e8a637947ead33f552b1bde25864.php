<a
    <?php echo e($attributes->except('wire:navigate')); ?>

    wire:navigate
>
<?php echo e($slot); ?>

</a><?php /**PATH E:\Web Server\xampp\htdocs\hitsu-blog\hitsuapp\resources\views\components\link.blade.php ENDPATH**/ ?>