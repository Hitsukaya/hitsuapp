<div x-data="{
    editor: null,
    content: <?php if ((object) ('content') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('content'->value()); ?>')<?php echo e('content'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('content'); ?>')<?php endif; ?>
}"
x-init="editor = new Tiptap.Editor({
    element: $refs.editor,
    extensions: [TiptapStarterKit],
    content: content,
    onUpdate({ editor }) {
        content = editor.getHTML();
    }
})"
>
    <div x-ref="editor"></div>
</div>

<script>
    import { Editor } from '@tiptap/core'
    import { StarterKit } from '@tiptap/starter-kit'

    window.Tiptap = { Editor, StarterKit }
</script>
<?php /**PATH E:\Web Server\xampp\htdocs\hitsu-blog\hitsuapp\resources\views\livewire\tiptap-editor.blade.php ENDPATH**/ ?>