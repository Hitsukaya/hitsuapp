<div x-data="{
    scroll: $refs.cards,
    interval: null,
    startAutoplay() {
        this.interval = setInterval(() => {
            this.scroll.scrollBy({ left: 300, behavior: 'smooth' });
        }, 3000);
    },
    stopAutoplay() {
        clearInterval(this.interval);
    },
    init() {
        this.startAutoplay();
    }
}" x-init="init" @mouseenter="stopAutoplay" @mouseleave="startAutoplay" class="relative overflow-hidden w-full bg-gray-100 dark:bg-neutral-900 py-8">
    <div x-ref="cards" class="flex gap-6 overflow-x-auto px-6 scroll-smooth snap-x snap-mandatory">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="relative min-w-[250px] max-w-[250px] bg-white rounded-2xl shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out snap-center flex-shrink-0">

                <!--[if BLOCK]><![endif]--><?php if($service->cover_image): ?>
                    <a href="<?php echo e(route('services.show', $service->slug)); ?>">
                        <img src="<?php echo e(Storage::url($service->cover_image)); ?>" class="rounded-t-2xl w-full h-[150px] object-cover" />
                    </a>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <div class="p-4">
                    <a href="<?php echo e(route('services.show', $service->slug)); ?>">
                        <h3 class="text-lg font-bold"><?php echo e($service->title); ?></h3>
                    </a>
                    <p class="text-sm text-gray-600 mb-2"><?php echo e(Str::limit($service->body_small, 100)); ?></p>
                    <a href="<?php echo e(route('services.show', $service->slug)); ?>" class="text-blue-600 text-sm hover:underline"><?php echo e($service->button_text ?? 'More'); ?></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <button @click="scroll.scrollBy({ left: -300, behavior: 'smooth' })"
        class="absolute left-3 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white shadow rounded-full p-2 transition">
        ‹
    </button>
    <button @click="scroll.scrollBy({ left: 300, behavior: 'smooth' })"
        class="absolute right-3 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white shadow rounded-full p-2 transition">
        ›
    </button>
</div>
<?php /**PATH E:\Web Server\xampp\htdocs\hitsu-blog\hitsuapp\Modules/Services\resources/views/livewire/service-list.blade.php ENDPATH**/ ?>