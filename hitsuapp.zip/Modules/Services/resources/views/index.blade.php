<x-layouts.app>

    <section class="py-4 bg-gray-100 dark:bg-neutral-950">
        <div class="text-center show-md py-2 p-6">
            <h1 class="font-sans text-black dark:text-white">Welcome to the Services Module!</h1>
        <div>
    </section>

</x-layouts.app>
