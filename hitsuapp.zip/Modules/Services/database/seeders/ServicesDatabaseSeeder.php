<?php

namespace Modules\Services\Database\Seeders;

use Illuminate\Database\Seeder;

class ServicesDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
