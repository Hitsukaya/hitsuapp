<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.service-category-resource.pages.create-service-category' => 'App\\Filament\\Resources\\ServiceCategoryResource\\Pages\\CreateServiceCategory',
    'app.filament.resources.service-category-resource.pages.edit-service-category' => 'App\\Filament\\Resources\\ServiceCategoryResource\\Pages\\EditServiceCategory',
    'app.filament.resources.service-category-resource.pages.list-service-categories' => 'App\\Filament\\Resources\\ServiceCategoryResource\\Pages\\ListServiceCategories',
    'app.filament.resources.service-category-resource.pages.view-service-category' => 'App\\Filament\\Resources\\ServiceCategoryResource\\Pages\\ViewServiceCategory',
    'app.filament.resources.service-resource.pages.create-service' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\CreateService',
    'app.filament.resources.service-resource.pages.edit-service' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\EditService',
    'app.filament.resources.service-resource.pages.list-services' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\ListServices',
    'app.filament.resources.service-resource.pages.view-service' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\ViewService',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.resources.user-resource.pages.view-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\ViewUser',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'E:\\Web Server\\xampp\\htdocs\\hitsu-blog\\hitsuapp\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'E:\\Web Server\\xampp\\htdocs\\hitsu-blog\\hitsuapp\\app\\Filament\\Resources\\ServiceCategoryResource.php' => 'App\\Filament\\Resources\\ServiceCategoryResource',
    'E:\\Web Server\\xampp\\htdocs\\hitsu-blog\\hitsuapp\\app\\Filament\\Resources\\ServiceResource.php' => 'App\\Filament\\Resources\\ServiceResource',
    'E:\\Web Server\\xampp\\htdocs\\hitsu-blog\\hitsuapp\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'E:\\Web Server\\xampp\\htdocs\\hitsu-blog\\hitsuapp\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'E:\\Web Server\\xampp\\htdocs\\hitsu-blog\\hitsuapp\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);