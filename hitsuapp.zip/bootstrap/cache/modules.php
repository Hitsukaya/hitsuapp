<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Services\\Providers\\ServicesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Services\\Providers\\ServicesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);